﻿namespace FlightBooking.Models
{
    public class User
    {
        public int Id { get; set; }
        public string? Username { get; set; }
        public string? Email { get; set; }
        public string? Password { get; set; }
        // Add any other properties as needed

        public ICollection<Booking> Bookings { get; set; }
    }
}
