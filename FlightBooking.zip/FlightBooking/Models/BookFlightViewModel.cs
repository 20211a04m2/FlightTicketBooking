﻿using System.ComponentModel.DataAnnotations;

namespace FlightBooking.Models
{
    public class BookFlightViewModel
    {
        public int FlightNumber { get; set; }
        public string? Departure { get; set; }
        public string? Destination { get; set; }
        public string? Date { get; set; }
        public string? Time { get; set; }

        [Required(ErrorMessage = "Number of tickets is required")]
        [Range(1, 60, ErrorMessage = "Please enter a value between 1 and 60")]
        public int TicketsCount { get; set; }
    }
}
