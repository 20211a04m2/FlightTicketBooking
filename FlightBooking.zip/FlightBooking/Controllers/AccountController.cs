﻿using FlightBooking.Models;
using Microsoft.AspNetCore.Mvc;

namespace FlightBooking.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account/Login
        public ActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Perform authentication logic here
            // Example: Check the entered username and password against the database records
            // If authentication is successful, set an authentication cookie or session variable

            // Redirect to the desired page after successful login
            return RedirectToAction("Search", "Flight");
        }

        // GET: Account/Signup
        [HttpGet]
        public ActionResult Signup()
        {
            return View();
        }

        // POST: Account/Signup
        [HttpPost]
        public ActionResult Signup(SignupViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Save the user registration details to the database
            // Example: Create a new User object and save it to the database

            // Redirect to a success page or perform additional actions

            return RedirectToAction("Login");
        }

        // GET: Account/SignupSuccess
        public ActionResult SignupSuccess()
        {
            return View();
        }

        // GET: /Account/Logout
        public ActionResult Logout()
        {
            // Clear the authentication cookie or session variable to log out the user
            // Example: Clear the authentication cookie
           // FormsAuthentication.SignOut();

            // Redirect the user to an appropriate page
            // Example: Redirect to the home page
            return RedirectToAction("Index", "Home");
        }


    }
}
