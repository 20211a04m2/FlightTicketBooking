﻿using FlightBooking.Data;
using FlightBooking.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FlightBooking.Controllers
{
    public class FlightController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FlightController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Flight/Search
        public ActionResult Search()
        {
            return View();
        }

        // POST: Flight/Search
        [HttpPost]
        public ActionResult Search(DateTime departureDate, DateTime arrivalDate)
        {
            // Perform flight search logic based on the departure and arrival dates
            // Retrieve flight results from the database

            List<Flight> flights = _context.Flights
                .Where(f => f.DepartureDateTime.Date == departureDate.Date && f.ArrivalDateTime.Date == arrivalDate.Date)
                .ToList();

            return View("SearchResults", flights);
        }
    }
}
