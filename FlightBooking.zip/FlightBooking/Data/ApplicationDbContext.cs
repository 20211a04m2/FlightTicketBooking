﻿using FlightBooking.Models;
using Microsoft.EntityFrameworkCore;

namespace FlightBooking.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Flight> Flights { get; set; }

        // Add any other DbSet properties for your entities

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure your entity relationships and constraints here
            base.OnModelCreating(modelBuilder);
        }
    }
}
