﻿using FlightBooking.Models;

namespace FlightBooking.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            var user = new User
            {
                Username = "john123",
                Password = "password123",
            };
            var user1 = new User
            {
                Username = "Mani",
                Password = "Mani123",
            };
            var user2 = new User
            {
                Username = "Harsha",
                Password = "Harsha123",
            };
            var user3 = new User
            {
                Username = "Abhi",
                Password = "Abhi123"
            };
            var flights = new List<Flight>
            {
            new Flight
            {
                FlightNumber = "ABC123",
                DepartureAirport = "Hyderabad",
                ArrivalAirport = "Banglore",
                DepartureDateTime = DateTime.Parse("2023-06-23"),
                ArrivalDateTime = DateTime.Parse("2023-06-24"),
                Price = 6000,
            },
            new Flight
            {
                FlightNumber = "ABC456",
                DepartureAirport = "Hyderabad",
                ArrivalAirport = "Banglore",
                DepartureDateTime = DateTime.Parse("2023-06-24"),
                ArrivalDateTime = DateTime.Parse("2023-06-25"),
                Price = 6000,
                SeatCount = 1,
            },
            new Flight
            {
                FlightNumber = "ABC678",
                DepartureAirport = "Delhi",
                ArrivalAirport = "Mumbai",
                DepartureDateTime = DateTime.Parse("2023-06-25"),
                ArrivalDateTime = DateTime.Parse("2023-06-26"),
                Price = 8000,
                SeatCount = 2,
            },
            new Flight
            {
                FlightNumber = "ABC987",
                DepartureAirport = "Kolkata",
                ArrivalAirport = "Hyderabad",
                DepartureDateTime = DateTime.Parse("2023-06-27"),
                ArrivalDateTime = DateTime.Parse("2023-06-28"),
                Price = 23000,
                SeatCount = 5,
            },
            new Flight
            {
                FlightNumber = "ABC786",
                DepartureAirport = "Hyderabad",
                ArrivalAirport = "Goa",
                DepartureDateTime = DateTime.Parse("2023-06-29"),
                ArrivalDateTime = DateTime.Parse("2023-06-30"),
                Price = 12000,
                SeatCount = 2,
            }
            };

            context.Users.Add(user);
            context.Users.Add(user1);
            context.Users.Add(user2);
            context.Users.Add(user3);
            context.Flights.AddRange(flights);

            context.SaveChanges();
        }
    }

}
